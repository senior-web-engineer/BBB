function module(n,o,r){(function(n){throw new Error}).call(this,r)}

